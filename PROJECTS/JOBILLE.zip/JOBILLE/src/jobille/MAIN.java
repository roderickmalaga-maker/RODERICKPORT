package jobille;

import java.text.DecimalFormat;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

public class MAIN extends javax.swing.JFrame {

    public MAIN() {
        initComponents();
        table.getColumnModel().getColumn(0).setPreferredWidth(30);
        table.getColumnModel().getColumn(1).setPreferredWidth(200);
    }

    public void addtable(int id, String Name, int Qty, Double Price) {

        DefaultTableModel dt = (DefaultTableModel) table.getModel();

        DecimalFormat df = new DecimalFormat("00.00");

        double totprice = Price * Double.valueOf(Qty);

        String TotalPrice = df.format(totprice);

        for (int row = 0; row < table.getRowCount(); row++) {
            if (Name == table.getValueAt(row, 1)) {

                dt.removeRow(table.convertColumnIndexToModel(row));
            }
        }
        Vector v = new Vector();
        v.add(id);
        v.add(Name);
        v.add(Qty);
        v.add(TotalPrice);

        dt.addRow(v);
    }

    public void cal() {
        int numofrow = table.getRowCount();
        double tot = 0.0;

        for (int i = 0; i < numofrow; i++) {
            double value = Double.valueOf(table.getValueAt(i, 3).toString());

            tot += value;
        }

        DecimalFormat df = new DecimalFormat("00.00");
        TOTAL.setText(df.format(tot));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        w5 = new javax.swing.JButton();
        w1 = new javax.swing.JButton();
        w2 = new javax.swing.JButton();
        w3 = new javax.swing.JButton();
        w4 = new javax.swing.JButton();
        q5 = new javax.swing.JLabel();
        q1 = new javax.swing.JLabel();
        q2 = new javax.swing.JLabel();
        q3 = new javax.swing.JLabel();
        q4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        b = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bal = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        TOTAL = new javax.swing.JLabel();
        pay = new javax.swing.JTextField();
        pay1 = new javax.swing.JButton();
        pay2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        w5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jobille/CjoyFries.png"))); // NOI18N
        w5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w5ActionPerformed(evt);
            }
        });
        jPanel1.add(w5, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, 160, 120));

        w1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jobille/4-pcCjoyFamBox.png"))); // NOI18N
        w1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w1ActionPerformed(evt);
            }
        });
        jPanel1.add(w1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 160, 120));

        w2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jobille/6-pcBurgerSteakFam.png"))); // NOI18N
        w2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w2ActionPerformed(evt);
            }
        });
        jPanel1.add(w2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, 160, 120));

        w3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jobille/6-pcChickenjoySolo.png"))); // NOI18N
        w3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w3ActionPerformed(evt);
            }
        });
        jPanel1.add(w3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 160, 120));

        w4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jobille/CjoyBurg.png"))); // NOI18N
        w4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w4ActionPerformed(evt);
            }
        });
        jPanel1.add(w4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 160, 120));

        q5.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        q5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q5.setText("0");
        jPanel1.add(q5, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, 160, -1));

        q1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        q1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q1.setText("0");
        jPanel1.add(q1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 160, -1));

        q2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        q2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q2.setText("0");
        jPanel1.add(q2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 150, 160, -1));

        q3.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        q3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q3.setText("0");
        jPanel1.add(q3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 150, 160, -1));

        q4.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        q4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q4.setText("0");
        jPanel1.add(q4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 340, 160, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 450));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "ITEM", "QTY", "PRICE"
            }
        ));
        jScrollPane1.setViewportView(table);

        b.setColumns(20);
        b.setRows(5);
        jScrollPane2.setViewportView(b);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 0, 680, 910));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setText("Balance:");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        bal.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        bal.setText("00");
        jPanel3.add(bal, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, 240, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel3.setText("Cash:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel4.setText("Total:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, -1, -1));

        TOTAL.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        TOTAL.setText("00");
        jPanel3.add(TOTAL, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, 240, -1));

        pay.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jPanel3.add(pay, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 120, 240, 50));

        pay1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        pay1.setText("PRINT");
        pay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pay1ActionPerformed(evt);
            }
        });
        jPanel3.add(pay1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 250, 140, 140));

        pay2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        pay2.setText("PAY");
        pay2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pay2ActionPerformed(evt);
            }
        });
        jPanel3.add(pay2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 90, 140, 140));

        jButton1.setText("DELETE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 20, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 650, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void w1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w1ActionPerformed
        int i = Integer.valueOf(q1.getText());
        ++i;
        q1.setText(String.valueOf(i));

        addtable(1,"4-pcCjoyFamBox", i, 300.00);
        cal();
    }//GEN-LAST:event_w1ActionPerformed

    private void w2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w2ActionPerformed
        int i = Integer.valueOf(q2.getText());
        ++i;
        q2.setText(String.valueOf(i));
        addtable(2,"6-pcBurgerSteakFam", i, 250.00);
        cal();
    }//GEN-LAST:event_w2ActionPerformed

    private void w3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w3ActionPerformed
        int i = Integer.valueOf(q3.getText());
        ++i;
        q3.setText(String.valueOf(i));
        addtable(3,"6-pcChickenjoySolo", i, 200.00);
        cal();

    }//GEN-LAST:event_w3ActionPerformed

    private void w4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w4ActionPerformed
        int i = Integer.valueOf(q4.getText());
        ++i;
        q4.setText(String.valueOf(i));
        addtable(4,"CjoyFries\t", i, 150.00);
        cal();
    }//GEN-LAST:event_w4ActionPerformed

    private void w5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w5ActionPerformed
        int i = Integer.valueOf(q5.getText());
        ++i;
        q5.setText(String.valueOf(i));
        addtable(5,"CjoyBurg\t ", i, 100.00);
        cal();
    }//GEN-LAST:event_w5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        DefaultTableModel dt = (DefaultTableModel) table.getModel();

        String r = dt.getValueAt(table.getSelectedRow(), 0).toString();

        int rw = table.getSelectedRow();
        dt.removeRow(rw);

        System.out.println(r);
        switch (r) {

            case " 1":
                q1.setText("0");
                break;
            case " 2":
                q2.setText("0");
                break;
            case " 3":
                q3.setText("0");
                break;
            case " 4":
                q4.setText("0");
                break;
            case " 5":
                q5.setText("0");
                break;

            default:
                System.out.println("Over");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void pay2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pay2ActionPerformed
        double tot = Double.valueOf(TOTAL.getText());
        double Paid = Double.valueOf(pay.getText());
        double balance = Paid - tot;

        DecimalFormat df = new DecimalFormat("00.00");
        bal.setText(String.valueOf(df.format(balance)));
    }//GEN-LAST:event_pay2ActionPerformed

    private void pay1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pay1ActionPerformed

        try {

            b.setText(b.getText()+"  G/F Main Mall, SM City Davao, Quimpo Boulevard, Davao City 8000\n");
            b.setText(b.getText()+"   082) 297-4380 / (082) 297-4381 / (082) 216-8000\n");
            b.setText(b.getText() +"    10:00 AM – 9:00 PMn\n");
            b.setText(b.getText() +"------------------------------------------------------------------------------------------------------\n");
            b.setText(b.getText() +" Item" + "\t\tQTY" + "\t\tPrice \n");
            b.setText(b.getText() +"------------------------------------------------------------------------------------------------------\n");

            DefaultTableModel dt = (DefaultTableModel) table.getModel();

            for (int i = 0; i < table.getRowCount(); i++) {

                String Name = dt.getValueAt(i, 1).toString();
                String QTY = dt.getValueAt(i, 2).toString();
                String Price = dt.getValueAt(i, 3).toString();
                b.setText(b.getText() + Name + "\t" + QTY + "\t\t" + Price +"\n");
            }
            b.setText(b.getText() + "------------------------------------------------------------------------------------------------------\n");
            b.setText(b.getText() + "Sub Total : " + TOTAL.getText() +"\n");
            b.setText(b.getText() + "Sub Total : " + pay.getText()+ "\n");
            b.setText(b.getText() + "Sub Total : " + bal.getText()+"\n");
            b.setText(b.getText() +"------------------------------------------------------------------------------------------------------\n");
            b.setText(b.getText() + "                                               Thank for purchasing \n");
            b.setText(b.getText() + "------------------------------------------------------------------------------------------------------\n");
        b.print();
        } catch (Exception e) {
              System.out.println(e);
        }
    }//GEN-LAST:event_pay1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MAIN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TOTAL;
    private javax.swing.JTextArea b;
    private javax.swing.JLabel bal;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField pay;
    private javax.swing.JButton pay1;
    private javax.swing.JButton pay2;
    private javax.swing.JLabel q1;
    private javax.swing.JLabel q2;
    private javax.swing.JLabel q3;
    private javax.swing.JLabel q4;
    private javax.swing.JLabel q5;
    private javax.swing.JTable table;
    private javax.swing.JButton w1;
    private javax.swing.JButton w2;
    private javax.swing.JButton w3;
    private javax.swing.JButton w4;
    private javax.swing.JButton w5;
    // End of variables declaration//GEN-END:variables
}
